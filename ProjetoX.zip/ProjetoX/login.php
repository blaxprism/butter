<?php
$nickname = $_POST[nickname];
$senha = $_POST[senha];



?>