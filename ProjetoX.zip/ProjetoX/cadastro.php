<?php
$email = $_POST[email];
$nickname = $_POST[nickname];
$senha = $_POST[senha];



?>